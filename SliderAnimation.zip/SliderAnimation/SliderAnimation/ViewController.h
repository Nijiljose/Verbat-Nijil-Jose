//
//  ViewController.h
//  SliderAnimation
//
//  Created by Nijil Jose on 29/03/17.
//
//

#import <UIKit/UIKit.h>
#import "DraggableViewBackground.h"
@interface ViewController : UIViewController<DraggableViewDelegate>
{
    DraggableViewBackground *draggableBackground;
}

@end

