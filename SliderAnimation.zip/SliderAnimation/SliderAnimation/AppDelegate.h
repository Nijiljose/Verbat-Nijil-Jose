//
//  AppDelegate.h
//  SliderAnimation
//
//  Created by Nijil Jose on 29/03/17.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

